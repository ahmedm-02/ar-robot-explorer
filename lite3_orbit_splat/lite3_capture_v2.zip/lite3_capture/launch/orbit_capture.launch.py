"""
Orbit + video capture launch.

Brings up in dependency order:

  t=0.0 s       realsense2_camera           (optional, default on)
  t=0.5 s       capture_orbit_node          (starts video recording)
  t=pre_roll    orbit_node                  (begins ramp into orbit motion)

The capture node auto-finalizes after `capture_duration_s` seconds.
An OnProcessExit handler shuts down the rest of the launch when capture
finishes, so the whole launch process terminates cleanly on its own —
which means a remote orchestrator (SSH from Emolga) can wait for the
launch to exit, then SCP the captured video back.

TIMING
------
The default capture_duration_s = 28 s covers:
    pre_roll (2 s) + ramp_up (2 s) + orbit_plateau (20 s)
                   + ramp_down (2 s) + post_roll  (2 s)
If you change orbit_duration_s in the orbit YAML, update capture_duration_s
here to match (or the recording will cut off mid-orbit).

PARAMETERS / LAUNCH ARGS
------------------------
  use_realsense       bool    default 'true'        ; launch the camera driver
  image_topic         str     default '/camera/color/image_raw'
  output_dir          str     default '/root/captures'
  basename            str     default 'orbit_capture'
  pre_roll_s          float   default '2.0'         ; capture-before-motion delay
  capture_duration_s  float   default '28.0'        ; total recording length
  fps                 float   default '30.0'        ; mp4 framerate
  cmd_topic           str     default '/cmd_vel'    ; orbit Twist target
  params_file         str     default orbit_params.yaml (from lite3_capture share)

EXAMPLES
--------
  # Default — RealSense + 28 s capture + standard orbit
  ros2 launch lite3_capture orbit_capture.launch.py

  # RealSense already running elsewhere
  ros2 launch lite3_capture orbit_capture.launch.py use_realsense:=false

  # Custom output location and name
  ros2 launch lite3_capture orbit_capture.launch.py \\
      output_dir:=/root/captures basename:=test_run_01

  # Shorter test (5 s plateau orbit) -- adjust both YAML and capture window
  ros2 launch lite3_capture orbit_capture.launch.py capture_duration_s:=13.0
"""

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    EmitEvent,
    IncludeLaunchDescription,
    RegisterEventHandler,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg_share = FindPackageShare('lite3_capture')
    default_params = PathJoinSubstitution([pkg_share, 'config', 'orbit_params.yaml'])

    # ---------- Launch arguments ----------
    use_realsense_arg = DeclareLaunchArgument(
        'use_realsense', default_value='true',
        description='Bring up the realsense2_camera node.'
    )
    image_topic_arg = DeclareLaunchArgument(
        'image_topic', default_value='/camera/color/image_raw',
        description='Camera image topic the capture node subscribes to.'
    )
    output_dir_arg = DeclareLaunchArgument(
        'output_dir', default_value='/root/captures',
        description='Where capture writes video and metadata.'
    )
    basename_arg = DeclareLaunchArgument(
        'basename', default_value='orbit_capture',
        description='Filename prefix; a timestamp is appended.'
    )
    pre_roll_arg = DeclareLaunchArgument(
        'pre_roll_s', default_value='2.0',
        description='Seconds of capture before orbit motion starts.'
    )
    capture_duration_arg = DeclareLaunchArgument(
        'capture_duration_s', default_value='28.0',
        description='Total seconds of video recording (covers pre-roll, orbit, post-roll).'
    )
    fps_arg = DeclareLaunchArgument(
        'fps', default_value='30.0',
        description='Output mp4 framerate.'
    )
    cmd_topic_arg = DeclareLaunchArgument(
        'cmd_topic', default_value='/cmd_vel',
        description="Remap target for orbit_node's relative 'cmd_vel' topic."
    )
    params_file_arg = DeclareLaunchArgument(
        'params_file', default_value=default_params,
        description='YAML parameter file for orbit_node.'
    )

    # ---------- 1. RealSense camera (optional) ----------
    # Includes the vendor launch under realsense2_camera/launch/rs_launch.py.
    # Only color stream is enabled here; depth/IMU disabled to keep bandwidth
    # and CPU manageable, and because splatfacto only consumes RGB.
    realsense = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('realsense2_camera'),
                'launch', 'rs_launch.py'
            ])
        ]),
        launch_arguments={
            'enable_color':         'true',
            'enable_depth':         'false',
            'enable_gyro':          'false',
            'enable_accel':         'false',
            'rgb_camera.profile':   '640x480x30',
        }.items(),
        condition=IfCondition(LaunchConfiguration('use_realsense')),
    )

    # ---------- 2. Capture node (starts at t=0.5 s) ----------
    # Brief delay to let the realsense node publish its first frames before
    # the capture subscriber comes up, so the CvBridge cold-start doesn't
    # drop the leading second of the recording.
    capture_node = Node(
        package='lite3_capture',
        executable='capture_orbit_node',
        name='capture_orbit_node',
        output='screen',
        parameters=[{
            'image_topic': LaunchConfiguration('image_topic'),
            'output_dir':  LaunchConfiguration('output_dir'),
            'basename':    LaunchConfiguration('basename'),
            'duration_s':  LaunchConfiguration('capture_duration_s'),
            'fps':         LaunchConfiguration('fps'),
        }],
    )
    capture_delayed = TimerAction(period=0.5, actions=[capture_node])

    # ---------- 3. Orbit node (starts at t=pre_roll_s) ----------
    # Reuses the standard orbit.launch.py so the parameter handling stays
    # in one place. cmd_topic and params_file are pass-throughs.
    orbit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([pkg_share, 'launch', 'orbit.launch.py'])
        ]),
        launch_arguments={
            'cmd_topic':   LaunchConfiguration('cmd_topic'),
            'params_file': LaunchConfiguration('params_file'),
        }.items(),
    )
    orbit_delayed = TimerAction(
        period=LaunchConfiguration('pre_roll_s'),
        actions=[orbit_launch],
    )

    # ---------- 4. Auto-shutdown on capture completion ----------
    # When capture_orbit_node exits (after duration_s elapses), emit a
    # Shutdown event so launch tears down realsense and any leftover
    # orbit launch state. Without this the launch would sit on the
    # realsense node forever.
    shutdown_on_capture_exit = RegisterEventHandler(
        OnProcessExit(
            target_action=capture_node,
            on_exit=[EmitEvent(event=Shutdown(
                reason='capture_orbit_node finished'
            ))],
        )
    )

    return LaunchDescription([
        use_realsense_arg,
        image_topic_arg,
        output_dir_arg,
        basename_arg,
        pre_roll_arg,
        capture_duration_arg,
        fps_arg,
        cmd_topic_arg,
        params_file_arg,
        realsense,
        capture_delayed,
        orbit_delayed,
        shutdown_on_capture_exit,
    ])
