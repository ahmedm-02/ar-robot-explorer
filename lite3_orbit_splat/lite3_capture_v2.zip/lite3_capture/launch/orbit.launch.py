"""
Launch the orbit_node with YAML parameters and a configurable cmd_vel remap.

Usage:
    ros2 launch lite3_capture orbit.launch.py
    ros2 launch lite3_capture orbit.launch.py cmd_topic:=/lite3/cmd_vel
    ros2 launch lite3_capture orbit.launch.py namespace:=lite3 params_file:=/abs/path/to/orbit.yaml
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # Locate the installed share dir for this package; this is where
    # the launch file finds the YAML param defaults at runtime.
    pkg_share = FindPackageShare('lite3_capture')
    default_params = PathJoinSubstitution(
        [pkg_share, 'config', 'orbit_params.yaml']
    )

    # Launch arguments are how the launch file exposes knobs to the
    # user without requiring them to edit any file. Each one is a
    # named string with a default value.
    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params,
        description='Path to the orbit_node YAML parameter file.',
    )
    cmd_topic_arg = DeclareLaunchArgument(
        'cmd_topic',
        default_value='/cmd_vel',
        description='Absolute topic the node publishes Twist on. '
                    'Remap target for the relative `cmd_vel` inside orbit_node.',
    )
    namespace_arg = DeclareLaunchArgument(
        'namespace',
        default_value='',
        description='Optional ROS namespace for the orbit node.',
    )

    orbit = Node(
        package='lite3_capture',
        executable='orbit_node',              # matches console_scripts in setup.py
        name='orbit_node',                    # node name in the ROS graph
        namespace=LaunchConfiguration('namespace'),
        parameters=[LaunchConfiguration('params_file')],
        remappings=[
            # The node creates a publisher on the relative topic 'cmd_vel'.
            # This line rewrites that to whatever 'cmd_topic' resolves to
            # at launch time. This is the proper ROS2 way: nodes use
            # relative names internally; launch files decide where they
            # actually land in the graph.
            ('cmd_vel', LaunchConfiguration('cmd_topic')),
        ],
        output='screen',
        emulate_tty=True,
    )

    return LaunchDescription([
        params_file_arg,
        cmd_topic_arg,
        namespace_arg,
        orbit,
    ])
