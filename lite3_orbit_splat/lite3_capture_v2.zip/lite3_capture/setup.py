import os
from glob import glob
from setuptools import setup

package_name = 'lite3_capture'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        # Mark this directory as a ROS2 ament package.
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        # Install package.xml so ament can find package metadata.
        ('share/' + package_name, ['package.xml']),
        # Install launch files so `ros2 launch lite3_capture <file>` works.
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
        # Install YAML parameter files alongside the package.
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Ayaan',
    maintainer_email='ayaan@stanford.edu',
    description='Object-capture behaviors for the DeepRobotics Lite3.',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        # Each entry is 'name = module:function'. After build+install,
        # `ros2 run lite3_capture orbit_node` invokes orbit_node.main().
        'console_scripts': [
            'orbit_node         = lite3_capture.orbit_node:main',
            'motion_test_node   = lite3_capture.motion_test_node:main',
            'capture_orbit_node = lite3_capture.capture_orbit_node:main',
        ],
    },
)
