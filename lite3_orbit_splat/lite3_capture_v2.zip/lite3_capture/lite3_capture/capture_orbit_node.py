#!/usr/bin/env python3
"""
Video capture node for orbit recording.

Subscribes to a camera image topic (default the RealSense color stream)
and writes frames to an mp4 for a configurable duration. Also writes a
sidecar JSON with capture metadata.

Designed to run alongside orbit_node inside orbit_capture.launch.py.
The launch uses an OnProcessExit handler on this node to shut down the
whole launch graph when capture finishes — so the launch ends on its own
when the recording duration elapses, which lets remote orchestrators
(e.g. an SSH session from Emolga) wait for completion without polling.

PARAMETERS
----------
image_topic        str    default '/camera/color/image_raw'
output_dir         str    default '/root/captures'
basename           str    default 'orbit_capture'
duration_s         float  default 28.0   (total wallclock recording window)
fps                float  default 30.0   (video file framerate; not the camera's)
codec              str    default 'mp4v' (OpenCV fourcc)

TOPIC ROUTING
-------------
The node uses the parameter directly here (rather than a remap) because
the image topic depends on the camera vendor's launch (realsense2_camera
publishes under /camera/...) and is better named than the abstract
'image_in'. If you need flexibility, remap or override via --ros-args.

METADATA SIDECAR (JSON)
-----------------------
Written alongside the .mp4 with:
  - video_path
  - frame_count, declared_fps, observed_fps
  - duration_s, started_at, finished_at (unix epoch seconds)
  - image_topic, codec, width, height
"""

import json
import os
import time
from datetime import datetime

import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image


class CaptureOrbitNode(Node):
    """Record incoming camera frames to an mp4 for a fixed duration."""

    def __init__(self):
        super().__init__('capture_orbit_node')

        # ---------- Parameters ----------
        self.declare_parameter('image_topic', '/camera/color/image_raw')
        self.declare_parameter('output_dir',  '/root/captures')
        self.declare_parameter('basename',    'orbit_capture')
        self.declare_parameter('duration_s',  28.0)
        self.declare_parameter('fps',         30.0)
        self.declare_parameter('codec',       'mp4v')

        self.image_topic = self.get_parameter('image_topic').value
        self.out_dir     = self.get_parameter('output_dir').value
        self.basename    = self.get_parameter('basename').value
        self.duration    = float(self.get_parameter('duration_s').value)
        self.fps         = float(self.get_parameter('fps').value)
        self.codec       = self.get_parameter('codec').value

        os.makedirs(self.out_dir, exist_ok=True)

        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        stem = f'{self.basename}_{ts}'
        self.video_path = os.path.join(self.out_dir, f'{stem}.mp4')
        self.meta_path  = os.path.join(self.out_dir, f'{stem}.json')

        # ---------- State ----------
        self.bridge      = CvBridge()
        self.writer      = None
        self.frame_count = 0
        self.frame_width = None
        self.frame_height = None
        self.first_frame_t = None
        self.last_frame_t  = None
        self.start_t = self.get_clock().now()
        self.done = False

        # ---------- Subscription ----------
        # Camera streams are usually high-rate and best-effort is fine for
        # video recording. Realsense2_camera's default publishes BEST_EFFORT
        # on the image topics, so matching that here keeps the QoS handshake
        # compatible without extra config.
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
            reliability=ReliabilityPolicy.BEST_EFFORT,
        )
        self.sub = self.create_subscription(
            Image, self.image_topic, self._image_cb, qos
        )

        # ---------- Watchdog timer ----------
        # Checks duration twice per second; finalizes when elapsed.
        self.timer = self.create_timer(0.5, self._check_done)

        self.get_logger().info(
            f"capture_orbit_node: topic='{self.image_topic}', "
            f"duration={self.duration}s, out='{self.video_path}'"
        )

    # ------------------------------------------------------------------
    def _image_cb(self, msg: Image):
        if self.done:
            return

        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().warning(f'cv_bridge failed: {e}')
            return

        # Lazy-open the VideoWriter once we know the frame dimensions.
        if self.writer is None:
            h, w = frame.shape[:2]
            self.frame_width  = w
            self.frame_height = h
            fourcc = cv2.VideoWriter_fourcc(*self.codec)
            self.writer = cv2.VideoWriter(
                self.video_path, fourcc, self.fps, (w, h)
            )
            if not self.writer.isOpened():
                self.get_logger().error(
                    f'cv2.VideoWriter failed to open {self.video_path} '
                    f'(codec={self.codec}). Check OpenCV codec support.'
                )
                self.done = True
                return
            self.first_frame_t = time.time()
            self.get_logger().info(
                f"Recording started: {w}x{h} @ {self.fps} fps -> {self.video_path}"
            )

        self.writer.write(frame)
        self.frame_count += 1
        self.last_frame_t = time.time()

    # ------------------------------------------------------------------
    def _check_done(self):
        elapsed = (self.get_clock().now() - self.start_t).nanoseconds * 1e-9
        if elapsed >= self.duration and not self.done:
            self._finalize()

    # ------------------------------------------------------------------
    def _finalize(self):
        if self.done:
            return
        self.done = True

        if self.writer is not None:
            self.writer.release()
            self.writer = None

        # Compute observed framerate from actual frame timestamps.
        observed_fps = None
        if (self.first_frame_t is not None
                and self.last_frame_t is not None
                and self.last_frame_t > self.first_frame_t
                and self.frame_count > 1):
            observed_fps = (self.frame_count - 1) / (self.last_frame_t - self.first_frame_t)

        meta = {
            'video_path':    self.video_path,
            'frame_count':   self.frame_count,
            'declared_fps':  self.fps,
            'observed_fps':  observed_fps,
            'duration_s':    self.duration,
            'image_topic':   self.image_topic,
            'codec':         self.codec,
            'width':         self.frame_width,
            'height':        self.frame_height,
            'started_at':    self.first_frame_t,
            'finished_at':   self.last_frame_t,
        }
        try:
            with open(self.meta_path, 'w') as f:
                json.dump(meta, f, indent=2)
        except Exception as e:
            self.get_logger().warning(f'Failed to write metadata: {e}')

        self.get_logger().info(
            f'Capture complete: {self.frame_count} frames '
            f'(observed {observed_fps:.1f} fps) -> {self.video_path}'
            if observed_fps else
            f'Capture complete: {self.frame_count} frames -> {self.video_path}'
        )
        self.get_logger().info(f'Metadata -> {self.meta_path}')


def main(args=None):
    rclpy.init(args=args)
    node = CaptureOrbitNode()
    try:
        # Spin until duration elapses (sets node.done) or user interrupts.
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        node.get_logger().info('KeyboardInterrupt: finalizing capture.')
    finally:
        try:
            node._finalize()
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
