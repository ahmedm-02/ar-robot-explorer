#!/usr/bin/env python3
"""
Single-axis motion test for the DeepRobotics Lite3.

Publishes a constant Twist on ONE body-frame axis for a short, ramped
duration. Use this BEFORE the orbit to answer two questions:

  1. Does the /cmd_vel rail actually move the dog?
     (publish forward at 0.10 m/s for 2 s, watch the dog)
  2. Do the axis signs match REP-103?
     (try lateral, then yaw — confirm each moves the expected direction)

REP-103 body frame: +x forward, +y left, +z up (CCW yaw positive).

Usage:
  # Forward at 0.10 m/s for 2 s
  ros2 run lite3_capture motion_test_node --ros-args \\
      -p axis:=forward -p velocity:=0.10 -p duration_s:=2.0

  # Lateral (sidestep left) at 0.10 m/s
  ros2 run lite3_capture motion_test_node --ros-args \\
      -p axis:=lateral -p velocity:=0.10

  # Yaw left (CCW) at 0.30 rad/s
  ros2 run lite3_capture motion_test_node --ros-args \\
      -p axis:=yaw -p velocity:=0.30

  # Negative values reverse direction on the same axis
  ros2 run lite3_capture motion_test_node --ros-args \\
      -p axis:=lateral -p velocity:=-0.10

A 0.5 s ramp in/out softens the start and stop.
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from geometry_msgs.msg import Twist


VALID_AXES = ('forward', 'lateral', 'yaw')


class MotionTestNode(Node):
    """Publish a ramped constant Twist on a single axis for a short duration."""

    def __init__(self):
        super().__init__('motion_test_node')

        # ---------- Parameters ----------
        self.declare_parameter('axis',              'forward')   # forward | lateral | yaw
        self.declare_parameter('velocity',          0.10)        # m/s for linear, rad/s for yaw
        self.declare_parameter('duration_s',        2.0)         # plateau duration
        self.declare_parameter('ramp_seconds',      0.5)         # ramp in/out
        self.declare_parameter('cmd_hz',            20.0)
        self.declare_parameter('max_linear_mps',    0.30)
        self.declare_parameter('max_angular_radps', 0.50)

        self.axis     = self.get_parameter('axis').value
        self.vel      = self.get_parameter('velocity').value
        self.duration = self.get_parameter('duration_s').value
        self.ramp     = self.get_parameter('ramp_seconds').value
        self.cmd_hz   = self.get_parameter('cmd_hz').value
        self.v_cap    = self.get_parameter('max_linear_mps').value
        self.w_cap    = self.get_parameter('max_angular_radps').value

        if self.axis not in VALID_AXES:
            self.get_logger().error(
                f"Invalid axis '{self.axis}'. Must be one of {VALID_AXES}."
            )
            raise SystemExit(2)

        # Pick the right cap based on axis (linear vs angular)
        cap = self.w_cap if self.axis == 'yaw' else self.v_cap
        if abs(self.vel) > cap:
            self.get_logger().warning(
                f'velocity {self.vel} exceeds cap {cap}; clamping (sign preserved).'
            )
            self.vel = math.copysign(cap, self.vel)

        # ---------- Publisher ----------
        # Same QoS as orbit_node; the launch / CLI remap target should be /cmd_vel.
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
        )
        self.pub = self.create_publisher(Twist, 'cmd_vel', qos)

        self.get_logger().info(
            f'Motion test: axis={self.axis}, velocity={self.vel:+.3f}, '
            f'duration={self.duration} s, ramp={self.ramp} s'
        )

        self.t0   = self.get_clock().now()
        self.done = False
        self.timer = self.create_timer(1.0 / self.cmd_hz, self._tick)

    def _envelope(self, t: float) -> float:
        """Trapezoidal scale in [0, 1]."""
        if t < 0.0:
            return 0.0
        if t < self.ramp:
            return t / self.ramp
        plateau_end = self.ramp + self.duration
        if t < plateau_end:
            return 1.0
        if t < plateau_end + self.ramp:
            return (plateau_end + self.ramp - t) / self.ramp
        return 0.0

    def _tick(self):
        if self.done:
            return

        elapsed = (self.get_clock().now() - self.t0).nanoseconds * 1e-9
        total   = 2.0 * self.ramp + self.duration

        if elapsed >= total:
            self.get_logger().info('Test complete; publishing zero Twist.')
            self._publish_zero()
            self.done = True
            self.timer.cancel()
            return

        scale = self._envelope(elapsed)
        cmd_val = self.vel * scale

        twist = Twist()
        if self.axis == 'forward':
            twist.linear.x  = cmd_val
        elif self.axis == 'lateral':
            twist.linear.y  = cmd_val
        elif self.axis == 'yaw':
            twist.angular.z = cmd_val
        self.pub.publish(twist)

    def _publish_zero(self):
        z = Twist()
        for _ in range(5):
            self.pub.publish(z)

    def emergency_stop(self):
        self.done = True
        try:
            self.timer.cancel()
        except Exception:
            pass
        self._publish_zero()


def main(args=None):
    rclpy.init(args=args)
    node = MotionTestNode()
    try:
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        node.get_logger().info('KeyboardInterrupt: stopping.')
    finally:
        try:
            node.emergency_stop()
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
