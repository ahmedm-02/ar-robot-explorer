#!/usr/bin/env python3
"""
Open-loop orbit behavior for the DeepRobotics Lite3 quadruped.

This node publishes geometry_msgs/Twist messages to a relative topic
named 'cmd_vel'. The launch file remaps this to the absolute /cmd_vel
that the DeepRobotics message_transformer bridge (Lite3_ROS) subscribes
to. The bridge converts each Twist into the high-level UDP packet the
RK3588 motion host expects.

References
----------
Lite3_ROS bridge:   https://github.com/DeepRoboticsLab/Lite3_ROS
Lite3_MotionSDK:    https://github.com/DeepRoboticsLab/Lite3_MotionSDK
ROS REP-103 (axes): https://www.ros.org/reps/rep-0103.html
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from geometry_msgs.msg import Twist


class OrbitNode(Node):
    """
    Publishes a trapezoidal-envelope orbit Twist to cmd_vel.

    Body frame (REP-103): +x forward, +y left, +z up (CCW yaw positive).
    Open-loop motion model:
        omega = 2*pi / T
        v_lat = radius * omega
        Twist.linear.y  = v_lat
        Twist.angular.z = omega
    The dog sidesteps tangentially while yawing inward at the same rate.
    """

    def __init__(self):
        super().__init__('orbit_node')

        # ---------- Declare parameters ----------
        # Each parameter has a sane default and can be overridden by a
        # YAML file (loaded via the launch file) or by '--ros-args -p name:=value'.
        self.declare_parameter('target_radius_m',   0.75)
        self.declare_parameter('orbit_period_s',    60.0)
        self.declare_parameter('orbit_duration_s',  20.0)
        self.declare_parameter('ramp_seconds',      2.0)
        self.declare_parameter('orbit_direction',   1)        # +1 CCW, -1 CW
        self.declare_parameter('lateral_sign',      1)        # flip if y-axis convention differs
        self.declare_parameter('yaw_sign',          1)        # flip if z-axis convention differs
        self.declare_parameter('max_linear_mps',    0.30)
        self.declare_parameter('max_angular_radps', 0.50)
        self.declare_parameter('cmd_hz',            20.0)

        # Cache parameter values into instance attributes.
        # Doing this once at startup avoids repeated map lookups in the hot loop.
        self.radius   = self.get_parameter('target_radius_m').value
        self.period   = self.get_parameter('orbit_period_s').value
        self.duration = self.get_parameter('orbit_duration_s').value
        self.ramp     = self.get_parameter('ramp_seconds').value
        self.dirn     = self.get_parameter('orbit_direction').value
        self.lat_sgn  = self.get_parameter('lateral_sign').value
        self.yaw_sgn  = self.get_parameter('yaw_sign').value
        self.v_cap    = self.get_parameter('max_linear_mps').value
        self.w_cap    = self.get_parameter('max_angular_radps').value
        self.cmd_hz   = self.get_parameter('cmd_hz').value

        # ---------- Compute steady-state motion command ----------
        self.omega = 2.0 * math.pi / self.period
        self.v_lat = self.radius * self.omega

        # Safety clamp. copysign preserves direction while limiting magnitude.
        if abs(self.v_lat) > self.v_cap:
            self.get_logger().warning(
                f'v_lat {self.v_lat:.3f} m/s exceeds cap; clamping to {self.v_cap}'
            )
            self.v_lat = math.copysign(self.v_cap, self.v_lat)
        if abs(self.omega) > self.w_cap:
            self.get_logger().warning(
                f'omega {self.omega:.3f} rad/s exceeds cap; clamping to {self.w_cap}'
            )
            self.omega = math.copysign(self.w_cap, self.omega)

        # ---------- Publisher with explicit QoS ----------
        # /cmd_vel must be RELIABLE so commands are not silently dropped
        # by the middleware. KEEP_LAST with depth 10 buffers a small history
        # for slow subscribers. VOLATILE means late-joining subscribers do not
        # receive old commands (we do not want a stale velocity replayed).
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
        )
        # Relative topic name 'cmd_vel'. The launch file remaps this to
        # the absolute '/cmd_vel' the Lite3 bridge subscribes to.
        self.pub = self.create_publisher(Twist, 'cmd_vel', qos)

        self.get_logger().info(
            f'Orbit configured: r={self.radius} m, T={self.period} s, '
            f'v_lat={self.v_lat:+.3f} m/s, omega={self.omega:+.3f} rad/s, '
            f'duration={self.duration} s, ramp={self.ramp} s, '
            f'direction={self.dirn:+d}'
        )

        # ---------- Timer ----------
        # rclpy's ROS-time-aware Timer ticks _tick at cmd_hz. Internally it
        # is driven by the executor we spin in main(). Using a Timer rather
        # than a thread keeps everything single-threaded and deterministic.
        self.t0   = self.get_clock().now()
        self.done = False
        self.timer = self.create_timer(1.0 / self.cmd_hz, self._tick)

    # ------------------------------------------------------------------
    # Motion envelope: scales the steady-state Twist over time.
    #
    #   scale
    #     1.0 |        _________________
    #         |       /                 \
    #         |      /                   \
    #     0.0 |_____/                     \______
    #          0  ramp   ramp+duration    ramp+duration+ramp   t
    # ------------------------------------------------------------------
    def _envelope(self, t: float) -> float:
        if t < 0.0:
            return 0.0
        if t < self.ramp:
            return t / self.ramp
        plateau_end = self.ramp + self.duration
        if t < plateau_end:
            return 1.0
        if t < plateau_end + self.ramp:
            return (plateau_end + self.ramp - t) / self.ramp
        return 0.0

    def _tick(self):
        """Timer callback: publish one Twist sample at cmd_hz."""
        if self.done:
            return

        elapsed = (self.get_clock().now() - self.t0).nanoseconds * 1e-9
        total   = 2.0 * self.ramp + self.duration

        if elapsed >= total:
            self.get_logger().info('Orbit complete; publishing zero Twist.')
            self._publish_zero()
            self.done = True
            self.timer.cancel()
            return

        scale = self._envelope(elapsed)

        # Build and publish the Twist. linear.y is body-frame lateral
        # (positive = left); angular.z is yaw (positive = CCW).
        twist = Twist()
        twist.linear.x  = 0.0
        twist.linear.y  = self.dirn * self.lat_sgn * self.v_lat * scale
        twist.angular.z = self.dirn * self.yaw_sgn * self.omega * scale
        self.pub.publish(twist)

    def _publish_zero(self):
        """Burst several zero Twists so the bridge definitely sees a stop."""
        z = Twist()
        for _ in range(5):
            self.pub.publish(z)

    def emergency_stop(self):
        """Idempotent shutdown: cancel timer and publish zero Twist."""
        self.done = True
        try:
            self.timer.cancel()
        except Exception:
            pass
        self._publish_zero()


def main(args=None):
    rclpy.init(args=args)
    node = OrbitNode()
    try:
        # spin_once + done flag lets the node exit cleanly when the
        # orbit finishes, without blocking forever in rclpy.spin().
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        node.get_logger().info('KeyboardInterrupt: stopping.')
    finally:
        try:
            node.emergency_stop()
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
