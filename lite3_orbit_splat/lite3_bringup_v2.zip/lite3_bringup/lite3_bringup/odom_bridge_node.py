#!/usr/bin/env python3
"""
Lite3 odometry bridge.

Subscribes to the relative topic 'odom_in' and:

  1. Broadcasts a TF transform: odom -> base_link
  2. Republishes the message as nav_msgs/Odometry on the relative topic 'odom_out'
     with corrected frame IDs and a corrected timestamp.

TOPIC ROUTING (the proper ROS2 idiom)
-------------------------------------
This node uses RELATIVE topic names. Topic routing happens at launch time via
remappings, NOT via parameters. Parameters are for configurable values
(frame ids, backdate, etc.); they are NOT for topic names.

To wire the bridge to /leg_odom2 and /odom from the command line:

    ros2 run lite3_bringup odom_bridge_node --ros-args \
        -r odom_in:=/leg_odom2 \
        -r odom_out:=/odom

Or in a launch file:

    Node(
        package='lite3_bringup',
        executable='odom_bridge_node',
        remappings=[
            ('odom_in',  '/leg_odom2'),
            ('odom_out', '/odom'),
        ],
    )

WHY REPUBLISH?
--------------
The dog publishes /leg_odom2 with a timestamp from its internal uptime
clock, which does not align with the NUC/container's ROS clock. Without
republishing, Nav2's DWB controller (via OdomSmoother) subscribes to /odom
and silently starves because no /odom topic exists, causing goals to be
accepted but never executed.

WHY HARDCODE FRAMES?
--------------------
The incoming /leg_odom2 may have empty or non-standard frame_id/child_frame_id.
Setting them explicitly from parameters (default 'odom' / 'base_link')
ensures the published TF and Odometry conform to the rest of the stack
regardless of what the dog reports.

WHY BACKDATE?
-------------
Even with ROS-clock timestamps, downstream consumers (LiDAR scans, SLAM,
costmaps) sometimes ask for transforms "now - epsilon". A small backdate
(default 0.1 s) gives a margin so they don't hit past-extrapolation errors.
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from rclpy.duration import Duration
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster


# Canonical relative topic names. Use remappings at launch time to route
# these to whatever absolute topics your system uses. Do not change these
# in source -- change the remappings in the launch file instead.
INPUT_TOPIC  = 'odom_in'
OUTPUT_TOPIC = 'odom_out'


class OdomBridgeNode(Node):
    """Republish odom_in as odom_out + TF (odom -> base_link)."""

    def __init__(self):
        super().__init__('odom_bridge_node')

        # ---------- Parameters (values, NOT topic names) ----------
        self.declare_parameter('odom_frame',         'odom')
        self.declare_parameter('base_frame',         'base_link')
        self.declare_parameter('publish_tf',         True)
        self.declare_parameter('publish_odom',       True)
        self.declare_parameter('tf_backdate_sec',    0.1)
        self.declare_parameter('subscription_depth', 50)

        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.do_tf      = bool(self.get_parameter('publish_tf').value)
        self.do_odom    = bool(self.get_parameter('publish_odom').value)
        self.backdate   = float(self.get_parameter('tf_backdate_sec').value)
        sub_depth       = int(self.get_parameter('subscription_depth').value)

        if not self.do_tf and not self.do_odom:
            self.get_logger().warning(
                'Both publish_tf and publish_odom are false; nothing to do.'
            )

        # Pre-compute backdate as a Duration (clamp to non-negative)
        self._backdate_dur = Duration(seconds=max(0.0, self.backdate))

        # ---------- Output: relative topic, remapped at launch ----------
        if self.do_odom:
            qos = QoSProfile(
                history=HistoryPolicy.KEEP_LAST,
                depth=50,
                reliability=ReliabilityPolicy.RELIABLE,
                durability=DurabilityPolicy.VOLATILE,
            )
            self.pub = self.create_publisher(Odometry, OUTPUT_TOPIC, qos)
        else:
            self.pub = None

        # ---------- Output: TF broadcaster ----------
        self.br = TransformBroadcaster(self) if self.do_tf else None

        # ---------- Input: relative topic, remapped at launch ----------
        self.sub = self.create_subscription(
            Odometry, INPUT_TOPIC, self._cb, sub_depth
        )

        # Resolve the final topic names (after any remapping) for logging.
        # This tells the user exactly where messages are flowing on the graph.
        resolved_in  = self.sub.topic_name
        resolved_out = self.pub.topic_name if self.pub is not None else '(disabled)'
        self.get_logger().info(
            f"odom_bridge: in='{resolved_in}' out='{resolved_out}' "
            f"tf={self.odom_frame}->{self.base_frame} ({'on' if self.do_tf else 'off'}) "
            f"backdate={self.backdate}s"
        )

    def _stamp(self):
        """Return current ROS time backdated by tf_backdate_sec."""
        stamped = self.get_clock().now() - self._backdate_dur
        return stamped.to_msg()

    def _cb(self, msg: Odometry):
        stamp = self._stamp()

        # Publish the cleaned Odometry message on odom_out
        if self.pub is not None:
            out = Odometry()
            out.header.stamp    = stamp
            out.header.frame_id = self.odom_frame
            out.child_frame_id  = self.base_frame
            out.pose            = msg.pose
            out.twist           = msg.twist
            self.pub.publish(out)

        # Broadcast TF: odom -> base_link
        if self.br is not None:
            t = TransformStamped()
            t.header.stamp    = stamp
            t.header.frame_id = self.odom_frame
            t.child_frame_id  = self.base_frame
            t.transform.translation.x = msg.pose.pose.position.x
            t.transform.translation.y = msg.pose.pose.position.y
            t.transform.translation.z = msg.pose.pose.position.z
            t.transform.rotation = msg.pose.pose.orientation
            self.br.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = OdomBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
