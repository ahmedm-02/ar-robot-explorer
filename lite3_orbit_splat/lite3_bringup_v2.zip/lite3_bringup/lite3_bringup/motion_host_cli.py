#!/usr/bin/env python3
"""
Lite3 motion host CLI: send direct UDP control commands.

Implements the simple-command protocol from
"Jueying Lite3 Motion Host Communication Interface v1.0.7-0"
(DEEP Robotics, 2024-05-15), section 1.

This is a DELIBERATE manual-invocation tool. Switching the dog into
'navigation' control mode makes any /cmd_vel publisher able to move it —
a safety-relevant action that should be initiated by an explicit human
command, not by an automatic bringup launch. The same reason DEEP Robotics
gates this behind the app's Lab Mode toggle.

PROTOCOL (simple commands, type=0)
----------------------------------
Each simple command is a 12-byte little-endian packet:

    struct CommandHead {
        uint32_t code;             // command code (e.g. 0x21010C03)
        uint32_t paramters_size;   // 0 for simple commands
        uint32_t type;             // 0 for simple commands
    };

Sent over UDP to the motion host (default port 43893).

MOTION HOST IP
--------------
Depends on your network configuration:
  - Wi-Fi segment 1:    192.168.1.120  (DEEP Robotics default)
  - Wi-Fi segment 2:    192.168.2.1
  - Direct Ethernet:    varies; the Jetson may or may not route to the
                        motion host's internal IP. The most reliable path
                        in that case is to run this script ON the dog
                        (ssh in, copy the script, python3 it).

EXAMPLES
--------
  # Switch dog to navigation mode (enables /cmd_vel motion)
  ros2 run lite3_bringup motion_host_cli navigation

  # Switch back to manual mode (safety: do this before walking away)
  ros2 run lite3_bringup motion_host_cli manual

  # Different motion host IP
  ros2 run lite3_bringup motion_host_cli navigation --host 192.168.1.120

  # List all available commands
  ros2 run lite3_bringup motion_host_cli --list

  # Run standalone without ROS (e.g. directly on the dog)
  python3 motion_host_cli.py navigation --host 127.0.0.1

REFERENCES
----------
- Jueying Lite3 Motion Host Communication Interface v1.0.7-0, section 1
- Lite3_MotionSDK GitHub repo (for IP/port determination)
"""

import argparse
import socket
import struct
import sys


# Simple commands (type=0, parameters_size=0). Each entry: (code, description).
# Section numbers refer to the protocol spec.
SIMPLE_COMMANDS = {
    # 1.2.1 Heartbeat
    'heartbeat':    (0x21040001, 'Heartbeat (send >=2 Hz to maintain control session)'),

    # 1.2.2 Basic state transitions
    'stand_sit':    (0x21010202, 'Toggle between sitting and standing'),
    'stop':         (0x21020C0E, 'Soft emergency stop'),
    'reset_zero':   (0x21010C05, 'Reset joints to zero'),

    # 1.2.4 Motion modes
    'pose_mode':    (0x21010D05, 'Pose mode (axis commands rotate the body)'),
    'move_mode':    (0x21010D06, 'Move mode (axis commands move the robot)'),

    # 1.2.5 Gait selection (move mode only)
    'flat_slow':    (0x21010300, 'Flat gait, slow gear'),
    'flat_medium':  (0x21010307, 'Flat gait, medium gear'),
    'flat_fast':    (0x21010303, 'Flat gait, fast gear'),
    'flat_crawl':   (0x21010406, 'Flat gait, crawl gear'),
    'rug_grip':     (0x21010402, 'RUG gait, grip gear'),
    'rug_general':  (0x21010401, 'RUG gait, general gear'),
    'rug_hstep':    (0x21010407, 'RUG gait, high-step gear'),

    # 1.2.7 Control modes  <-- the key ones for autonomous control
    'navigation':   (0x21010C03, 'Switch to NAVIGATION mode (perception host owns velocity)'),
    'manual':       (0x21010C02, 'Switch to MANUAL mode (controller owns velocity)'),

    # 1.2.8 Data save
    'save_data':    (0x21010C01, 'Save last 100s of data and soft-stop'),

    # 1.2.9 Keep stepping (complex actually; we send the simple wrapper here)
    # Note: per spec this command takes a value (1=enable, 2=disable). The
    # simple variant defaults to enable; for explicit control use the doc.
}


def encode_simple_command(code: int) -> bytes:
    """
    Encode a simple command as a 12-byte little-endian packet.

    Format per spec section 1.1.1:
        struct CommandHead {
            uint32_t code;             // 4 bytes
            uint32_t paramters_size;   // 4 bytes, =0 for simple
            uint32_t type;             // 4 bytes, =0 for simple
        };
    '<' = little-endian, 'III' = three uint32.
    """
    return struct.pack('<III', code, 0, 0)


def send_command(host: str, port: int, code: int, verbose: bool = True) -> None:
    """Send a single simple-command packet to the motion host."""
    payload = encode_simple_command(code)
    if verbose:
        hex_dump = ' '.join(f'{b:02x}' for b in payload)
        print(f"-> {host}:{port}  code=0x{code:08X}  bytes=[{hex_dump}]")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.sendto(payload, (host, port))
    finally:
        sock.close()


def list_commands() -> None:
    """Print the table of available commands."""
    print("Available commands:\n")
    width = max(len(name) for name in SIMPLE_COMMANDS)
    for name, (code, desc) in sorted(SIMPLE_COMMANDS.items()):
        print(f"  {name:<{width}}  0x{code:08X}  {desc}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description='Send a UDP control command to the Lite3 motion host.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=("Examples:\n"
                "  ros2 run lite3_bringup motion_host_cli navigation\n"
                "  ros2 run lite3_bringup motion_host_cli manual\n"
                "  ros2 run lite3_bringup motion_host_cli stand_sit\n"
                "  ros2 run lite3_bringup motion_host_cli --list\n"),
    )
    parser.add_argument('command', nargs='?',
                        help='Command name (use --list to see options).')
    parser.add_argument('--host', default='192.168.1.120',
                        help='Motion host IP (default: 192.168.1.120). '
                             'Try 192.168.2.1 on segment 2, or your dog-side '
                             'internal IP if running from the perception host.')
    parser.add_argument('--port', type=int, default=43893,
                        help='Motion host UDP port (default: 43893).')
    parser.add_argument('--list', action='store_true',
                        help='List all available commands and exit.')
    parser.add_argument('-q', '--quiet', action='store_true',
                        help='Suppress the outgoing-packet log line.')
    args = parser.parse_args()

    if args.list:
        list_commands()
        return 0

    if args.command is None:
        parser.print_help()
        return 2

    if args.command not in SIMPLE_COMMANDS:
        print(f"Error: unknown command '{args.command}'.", file=sys.stderr)
        print("Use --list to see available commands.", file=sys.stderr)
        return 2

    code, desc = SIMPLE_COMMANDS[args.command]
    send_command(args.host, args.port, code, verbose=not args.quiet)
    return 0


if __name__ == '__main__':
    sys.exit(main())
