import os
from glob import glob
from setuptools import setup

package_name = 'lite3_bringup'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        # Register as ament package
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        # Install package.xml
        ('share/' + package_name, ['package.xml']),
        # Install launch files
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
        # Install config files
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
        # Install URDF/xacro files
        (os.path.join('share', package_name, 'urdf'),
            glob('urdf/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Ayaan',
    maintainer_email='ayaan@stanford.edu',
    description='Bringup stack for the Lite3 quadruped (LiDAR, odom bridge, SLAM, Nav2).',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'odom_bridge_node = lite3_bringup.odom_bridge_node:main',
            'motion_host_cli  = lite3_bringup.motion_host_cli:main',
        ],
    },
)
