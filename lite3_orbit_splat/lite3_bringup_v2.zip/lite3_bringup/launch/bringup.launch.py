"""
lite3_bringup full-stack launch.

Brings up the dog-facing ROS2 stack in dependency order:

  t=0.0 s   RPLIDAR driver           (provides /scan)
  t=0.0 s   lite3 odom_bridge_node   (provides /odom + TF odom->base_link)
  t=0.0 s   robot_state_publisher    (provides TF base_link->laser from URDF)
  t=2.0 s   slam_toolbox             (optional, default on)
  t=5.0 s   nav2_bringup             (optional, default OFF -- currently uncertified)

The 2 s / 5 s delays let earlier nodes register their TF/topics before
downstream consumers come up, avoiding "TF tree has unconnected trees"
warnings on startup.

PREREQUISITES
-------------
Before launching, both the lite3_bringup workspace AND the rplidar_ros
workspace must be sourced inside the container, e.g.:

    source /opt/ros/foxy/setup.bash
    source /root/rplidar_ws_foxy/install/setup.bash
    source /root/lite3_ws/install/setup.bash

(Or put those in /root/.bashrc.) Without sourcing rplidar_ws_foxy, the
rplidar_node executable cannot be found and the bringup will error out.

TOPIC ROUTING
-------------
The odom_bridge_node uses RELATIVE topic names 'odom_in' and 'odom_out'.
The launch arguments 'input_odom_topic' and 'output_odom_topic' set the
remap targets at launch time. This is the proper ROS2 idiom: topic
ROUTING goes through remappings, topic NAMES in source stay relative.

Arguments:
  use_slam            bool      default 'true'   ; bring up slam_toolbox
  use_nav2            bool      default 'false'  ; bring up nav2_bringup
  serial_port         string    default '/dev/ttyUSB0'  ; LiDAR device path
  input_odom_topic    string    default '/leg_odom2'    ; what /odom_in remaps to
  output_odom_topic   string    default '/odom'         ; what /odom_out remaps to
"""

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    Command,
    LaunchConfiguration,
    PathJoinSubstitution,
)
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # ---------- Resolved package paths ----------
    pkg_share   = FindPackageShare('lite3_bringup')
    nav2_params = PathJoinSubstitution([pkg_share, 'config', 'nav2_params.yaml'])
    slam_params = PathJoinSubstitution([pkg_share, 'config', 'mapper_async.yaml'])
    urdf_file   = PathJoinSubstitution([pkg_share, 'urdf',   'lite3_minimal.urdf.xacro'])

    # ---------- Launch arguments ----------
    use_slam_arg = DeclareLaunchArgument(
        'use_slam', default_value='true',
        description='Bring up slam_toolbox.'
    )
    use_nav2_arg = DeclareLaunchArgument(
        'use_nav2', default_value='false',
        description='Bring up nav2_bringup (default off; currently uncertified on this system).'
    )
    serial_port_arg = DeclareLaunchArgument(
        'serial_port', default_value='/dev/ttyUSB0',
        description='LiDAR serial device.'
    )
    input_odom_arg = DeclareLaunchArgument(
        'input_odom_topic', default_value='/leg_odom2',
        description="Absolute topic the bridge subscribes to (remap target for 'odom_in')."
    )
    output_odom_arg = DeclareLaunchArgument(
        'output_odom_topic', default_value='/odom',
        description="Absolute topic the bridge publishes to (remap target for 'odom_out')."
    )

    # ---------- 1. RPLIDAR (direct Node, no RViz bundled) ----------
    # We launch rplidar_node directly rather than including
    # view_rplidar_a2m8_launch.py because that vendor launch also starts
    # an RViz2 instance, which fails in a headless container. Parameters
    # below match the standard A2M8 configuration.
    rplidar = Node(
        package='rplidar_ros',
        executable='rplidar_node',
        name='rplidar_node',
        output='screen',
        parameters=[{
            'serial_port':      LaunchConfiguration('serial_port'),
            'serial_baudrate':  115200,        # A2M8 default
            'frame_id':         'laser',
            'inverted':         False,
            'angle_compensate': True,
            'scan_mode':        'Sensitivity',
        }],
    )

    # ---------- 2. Odom bridge: /leg_odom2 -> /odom + TF ----------
    odom_bridge = Node(
        package='lite3_bringup',
        executable='odom_bridge_node',
        name='odom_bridge_node',
        output='screen',
        parameters=[{
            'odom_frame':         'odom',
            'base_frame':         'base_link',
            'publish_tf':         True,
            'publish_odom':       True,
            'tf_backdate_sec':    0.1,
            'subscription_depth': 50,
        }],
        remappings=[
            ('odom_in',  LaunchConfiguration('input_odom_topic')),
            ('odom_out', LaunchConfiguration('output_odom_topic')),
        ],
    )

    # ---------- 3. robot_state_publisher with minimal URDF ----------
    # The xacro command produces XML on stdout; Command() captures it at
    # launch time. We wrap it in ParameterValue(..., value_type=str) so
    # launch_ros knows it's a string and does NOT try to YAML-parse it.
    # Without that wrapper, XML comments containing colons (e.g. "What this
    # file provides:") trip yaml.safe_load and the launch fails.
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': ParameterValue(
                Command(['xacro ', urdf_file]),
                value_type=str,
            ),
        }],
    )

    # ---------- 4. SLAM toolbox (optional, delayed 2 s) ----------
    slam = TimerAction(
        period=2.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    PathJoinSubstitution([
                        FindPackageShare('slam_toolbox'),
                        'launch', 'online_async_launch.py'
                    ])
                ]),
                launch_arguments={
                    'params_file':  slam_params,
                    'use_sim_time': 'false',
                }.items(),
                condition=IfCondition(LaunchConfiguration('use_slam')),
            )
        ],
    )

    # ---------- 5. Nav2 (optional, delayed 5 s) ----------
    nav2 = TimerAction(
        period=5.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    PathJoinSubstitution([
                        FindPackageShare('nav2_bringup'),
                        'launch', 'navigation_launch.py'
                    ])
                ]),
                launch_arguments={
                    'params_file':  nav2_params,
                    'use_sim_time': 'false',
                }.items(),
                condition=IfCondition(LaunchConfiguration('use_nav2')),
            )
        ],
    )

    return LaunchDescription([
        use_slam_arg,
        use_nav2_arg,
        serial_port_arg,
        input_odom_arg,
        output_odom_arg,
        rplidar,
        odom_bridge,
        robot_state_publisher,
        slam,
        nav2,
    ])
