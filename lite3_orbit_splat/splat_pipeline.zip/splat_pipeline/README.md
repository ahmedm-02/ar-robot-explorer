# splat_pipeline

Two shell scripts that turn an orbit-capture video from the Lite3 into a
Gaussian splat trained with Nerfstudio's `splatfacto`.

Designed to run on Emolga, paired with the `lite3_capture` ROS2 package
on the NUC (which produces the video).

## Layout

```
splat_pipeline/
├── splat_pipeline.sh    # video -> Nerfstudio dataset -> splatfacto -> .ply export
├── fetch_and_splat.sh   # end-to-end: triggers capture on NUC, pulls video, calls splat_pipeline.sh
└── README.md
```

## Prerequisites

**On Emolga:**

- Nerfstudio installed in a conda env (default name `nerfstudio`)
- COLMAP installed (needed by `ns-process-data`)
- SSH config alias `nuc` resolving to the NUC (matches existing setup)
- Local directory for captured videos (default `/home/robodog/gaussian_captures`)
- Local directory for splat runs (default `/home/robodog/splat_runs`)

Quick check both Nerfstudio commands resolve:

```bash
conda activate nerfstudio
which ns-process-data ns-train ns-export
```

If any are missing, install Nerfstudio first:
<https://docs.nerf.studio/quickstart/installation.html>

**On the NUC:**

- `foxy_ros` container with `lite3_capture` (latest version, including
  `capture_orbit_node` and `orbit_capture.launch.py`) built and sourced
- `ros-foxy-realsense2-camera` installed in the container
- `ros-foxy-cv-bridge` and `python3-opencv` installed in the container
- RealSense camera plugged in and visible to the container
- Dog transfer stack running and dog in navigation mode

## Usage

### Mode A: full pipeline from Emolga (recommended)

```bash
# Defaults: timestamped run name, 28 s capture window
./fetch_and_splat.sh

# Named run, custom duration
./fetch_and_splat.sh chair_orbit_01 28
```

This will:
1. SSH to the NUC and invoke `ros2 launch lite3_capture orbit_capture.launch.py`
2. Wait for the launch to auto-terminate (capture node finishes, shutdown event fires)
3. SCP the video and metadata JSON from the container -> NUC host -> Emolga
4. Run `splat_pipeline.sh` on the local video copy

### Mode B: run the parts separately

Useful if you've already captured the video and just want to (re-)train the splat.

```bash
# Capture only — from the NUC container
ros2 launch lite3_capture orbit_capture.launch.py basename:=test_run_01

# Bring the video over manually (from Emolga)
ssh nuc 'sudo docker cp foxy_ros:/root/captures/test_run_01_*.mp4 /tmp/'
scp nuc:/tmp/test_run_01_*.mp4 /home/robodog/gaussian_captures/

# Train the splat
./splat_pipeline.sh /home/robodog/gaussian_captures/test_run_01_<timestamp>.mp4
```

## Environment overrides

Both scripts respect environment variables for paths and tooling:

```bash
# Use a different conda env
NS_CONDA_ENV=ns_dev ./splat_pipeline.sh /tmp/video.mp4

# Different captures directory
LOCAL_CAPTURES=/data/captures ./fetch_and_splat.sh my_run

# Different conda installation
CONDA_SH=~/miniconda3/etc/profile.d/conda.sh ./splat_pipeline.sh /tmp/video.mp4

# More training frames
NUM_FRAMES=300 ./splat_pipeline.sh /tmp/video.mp4
```

## Outputs

For a run named `chair_orbit_01`, the splat pipeline produces:

```
/home/robodog/splat_runs/chair_orbit_01/
├── ns_data/                   # Nerfstudio dataset (frames, transforms.json)
├── outputs/<dataset>/<method>/<timestamp>/
│   └── config.yml             # training config
├── export/
│   └── *.ply                  # the Gaussian splat
└── splat_pipeline.log
```

## Viewing the splat

```bash
conda activate nerfstudio
CONFIG=$(find /home/robodog/splat_runs/chair_orbit_01/outputs -name config.yml | sort | tail -1)
ns-viewer --load-config "$CONFIG"
```

The viewer prints a localhost URL; open it in a browser.

## Notes / known sharp edges

- `ns-process-data video` runs COLMAP, which can take a while (minutes for ~150 frames).
- `ns-train splatfacto` is GPU-bound. Default training is ~30k steps; expect 5-15 min on a 3090, longer otherwise.
- The default 28 s capture window assumes the orbit YAML's default timing (2 s pre-roll + 2 s ramp + 20 s plateau + 2 s ramp + 2 s post-roll). If you change `orbit_duration_s` in the orbit YAML, update `capture_duration_s` in the launch invocation to match.
- For object-centered splats, hand-aim the dog so the object stays roughly centered through the orbit. Open-loop drift will degrade reconstruction quality at the edges of the orbit.
