#!/usr/bin/env bash
#
# splat_pipeline.sh — process an orbit video into a Gaussian splat.
#
# Runs on Emolga (or any machine with Nerfstudio installed). Takes a video
# path, produces a Nerfstudio dataset (frames + colmap poses), trains a
# splatfacto model, and exports a .ply Gaussian splat.
#
# USAGE
#   ./splat_pipeline.sh <video_path> [output_name]
#
# EXAMPLES
#   ./splat_pipeline.sh /home/robodog/gaussian_captures/orbit_01.mp4
#   ./splat_pipeline.sh /tmp/orbit.mp4 my_custom_name
#
# ENV OVERRIDES (optional)
#   SPLAT_BASE_DIR   default /home/robodog/splat_runs
#   NS_CONDA_ENV     default nerfstudio
#   NUM_FRAMES       default 150
#   CONDA_SH         default ~/anaconda3/etc/profile.d/conda.sh
#                    (try ~/miniconda3/... if conda isn't found)
#
# OUTPUTS
#   $SPLAT_BASE_DIR/<output_name>/
#     ns_data/         Nerfstudio dataset (frames, transforms.json, etc.)
#     outputs/         splatfacto training run
#     export/          exported .ply Gaussian splat
#     splat_pipeline.log

set -euo pipefail

# ---------- args ----------
VIDEO_PATH="${1:-}"
if [[ -z "${VIDEO_PATH}" ]]; then
  echo "usage: $0 <video_path> [output_name]" >&2
  exit 2
fi
if [[ ! -f "${VIDEO_PATH}" ]]; then
  echo "error: video not found at ${VIDEO_PATH}" >&2
  exit 2
fi
OUTPUT_NAME="${2:-$(basename "${VIDEO_PATH}" .mp4)}"

# ---------- env ----------
SPLAT_BASE_DIR="${SPLAT_BASE_DIR:-/home/robodog/splat_runs}"
NS_CONDA_ENV="${NS_CONDA_ENV:-nerfstudio}"
NUM_FRAMES="${NUM_FRAMES:-150}"
CONDA_SH="${CONDA_SH:-${HOME}/anaconda3/etc/profile.d/conda.sh}"

RUN_DIR="${SPLAT_BASE_DIR}/${OUTPUT_NAME}"
mkdir -p "${RUN_DIR}"
LOG="${RUN_DIR}/splat_pipeline.log"

# Mirror stdout/stderr to the log without losing terminal visibility.
exec > >(tee -a "${LOG}") 2>&1

echo "============================================================"
echo "  splat_pipeline.sh"
echo "  video:       ${VIDEO_PATH}"
echo "  run dir:     ${RUN_DIR}"
echo "  conda env:   ${NS_CONDA_ENV}"
echo "  num frames:  ${NUM_FRAMES}"
echo "  started:     $(date -Iseconds)"
echo "============================================================"

# ---------- conda activate ----------
if [[ ! -f "${CONDA_SH}" ]]; then
  echo "error: conda.sh not found at ${CONDA_SH}" >&2
  echo "set CONDA_SH=/path/to/conda.sh and rerun" >&2
  exit 3
fi
# shellcheck disable=SC1090
source "${CONDA_SH}"
conda activate "${NS_CONDA_ENV}"

# Sanity check the Nerfstudio CLI is on PATH
for cmd in ns-process-data ns-train ns-export; do
  if ! command -v "${cmd}" >/dev/null 2>&1; then
    echo "error: ${cmd} not found in conda env '${NS_CONDA_ENV}'" >&2
    exit 4
  fi
done

cd "${RUN_DIR}"

# ---------- 1. ns-process-data ----------
echo ""
echo "=== [1/3] ns-process-data video → ns_data/ ==="
if [[ -d "${RUN_DIR}/ns_data" ]]; then
  echo "(ns_data exists; skipping. Remove it to force reprocess.)"
else
  ns-process-data video \
    --data "${VIDEO_PATH}" \
    --output-dir "${RUN_DIR}/ns_data" \
    --num-frames-target "${NUM_FRAMES}"
fi

# ---------- 2. ns-train splatfacto ----------
echo ""
echo "=== [2/3] ns-train splatfacto ==="
# `ns-train` writes outputs/<dataset>/<method>/<timestamp>/config.yml
ns-train splatfacto --data "${RUN_DIR}/ns_data" --vis viewer+wandb --viewer.quit-on-train-completion True 2>/dev/null \
  || ns-train splatfacto --data "${RUN_DIR}/ns_data"

# ---------- 3. Locate config + export ----------
echo ""
echo "=== [3/3] ns-export gaussian-splat ==="
# Most-recent config.yml under outputs/
CONFIG=$(find "${RUN_DIR}/outputs" -name config.yml 2>/dev/null | sort | tail -1 || true)
if [[ -z "${CONFIG}" ]]; then
  echo "error: no config.yml found under ${RUN_DIR}/outputs" >&2
  exit 5
fi
echo "Using config: ${CONFIG}"

mkdir -p "${RUN_DIR}/export"
ns-export gaussian-splat \
  --load-config "${CONFIG}" \
  --output-dir "${RUN_DIR}/export"

echo ""
echo "============================================================"
echo "  DONE."
echo "  Splat:   ${RUN_DIR}/export"
echo "  Config:  ${CONFIG}"
echo "  Log:     ${LOG}"
echo "  Finished: $(date -Iseconds)"
echo "============================================================"
