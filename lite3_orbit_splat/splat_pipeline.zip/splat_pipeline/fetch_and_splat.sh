#!/usr/bin/env bash
#
# fetch_and_splat.sh — full pipeline orchestrator.
#
# Runs on Emolga. Does the whole chain:
#
#   1. SSH into the NUC, docker-exec into foxy_ros, run orbit_capture.launch.
#      (Launch auto-shuts down when capture finishes.)
#   2. SCP the captured video and metadata back to Emolga.
#   3. Run splat_pipeline.sh on the local copy to train the splat.
#
# Assumes:
#   - SSH config has a 'nuc' alias (set up in ~/.ssh/config)
#   - foxy_ros container is on the NUC and pre-built with lite3_capture
#   - dog transfer stack is running and dog is in navigation mode
#     (run the mode-switch python script on the dog before invoking this)
#
# USAGE
#   ./fetch_and_splat.sh [run_name] [capture_duration_s]
#
#   run_name             default: timestamped 'orbit_<YYYYMMDD_HHMMSS>'
#   capture_duration_s   default: 28 (matches default orbit timing)
#
# ENV OVERRIDES (optional)
#   NUC_USER          default 'dog'
#   NUC_HOST          default 'nuc'           (ssh alias)
#   CONTAINER         default 'foxy_ros'
#   REMOTE_CAPTURES   default '/root/captures' (inside container)
#   LOCAL_CAPTURES    default '/home/robodog/gaussian_captures'

set -euo pipefail

# ---------- args ----------
RUN_NAME="${1:-orbit_$(date +%Y%m%d_%H%M%S)}"
CAPTURE_DURATION_S="${2:-28}"

# ---------- env ----------
NUC_USER="${NUC_USER:-dog}"
NUC_HOST="${NUC_HOST:-nuc}"
CONTAINER="${CONTAINER:-foxy_ros}"
REMOTE_CAPTURES="${REMOTE_CAPTURES:-/root/captures}"
LOCAL_CAPTURES="${LOCAL_CAPTURES:-/home/robodog/gaussian_captures}"

mkdir -p "${LOCAL_CAPTURES}"

echo "============================================================"
echo "  fetch_and_splat.sh"
echo "  run name:        ${RUN_NAME}"
echo "  capture window:  ${CAPTURE_DURATION_S} s"
echo "  remote:          ${NUC_USER}@${NUC_HOST}  (container '${CONTAINER}')"
echo "  remote captures: ${REMOTE_CAPTURES}"
echo "  local captures:  ${LOCAL_CAPTURES}"
echo "============================================================"

# ---------- 1. Trigger orbit_capture on the NUC ----------
echo ""
echo "=== [1/3] launching orbit_capture on NUC (this blocks until capture ends) ==="
# We pipe a heredoc into bash inside the container so all the necessary
# sourcing happens within one shell. The launch auto-terminates when the
# capture node finishes (OnProcessExit -> Shutdown event), so this SSH
# command returns when capture is done.
ssh -T "${NUC_USER}@${NUC_HOST}" "sudo docker exec -i ${CONTAINER} bash" <<EOF
set -e
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0
source /opt/ros/foxy/setup.bash
source /root/rplidar_ws_foxy/install/setup.bash 2>/dev/null || true
source /root/lite3_ws/install/setup.bash

# Make sure output dir exists in the container
mkdir -p ${REMOTE_CAPTURES}

ros2 launch lite3_capture orbit_capture.launch.py \\
    basename:=${RUN_NAME} \\
    output_dir:=${REMOTE_CAPTURES} \\
    capture_duration_s:=${CAPTURE_DURATION_S}
EOF

# ---------- 2. Find the produced files and copy back ----------
echo ""
echo "=== [2/3] copying video + metadata from NUC ==="
# The capture node writes ${REMOTE_CAPTURES}/${RUN_NAME}_<timestamp>.{mp4,json}
# We grab the newest pair matching the basename.
LATEST_MP4=$(ssh "${NUC_USER}@${NUC_HOST}" \
  "sudo docker exec ${CONTAINER} bash -lc 'ls -t ${REMOTE_CAPTURES}/${RUN_NAME}_*.mp4 2>/dev/null | head -1'")
if [[ -z "${LATEST_MP4}" ]]; then
  echo "error: no mp4 found in ${REMOTE_CAPTURES} matching ${RUN_NAME}_*.mp4" >&2
  exit 6
fi
LATEST_JSON="${LATEST_MP4%.mp4}.json"
LOCAL_MP4="${LOCAL_CAPTURES}/$(basename "${LATEST_MP4}")"
LOCAL_JSON="${LOCAL_CAPTURES}/$(basename "${LATEST_JSON}")"

# docker cp from container to NUC host, then scp from NUC host to Emolga.
# We can't scp directly out of the container.
ssh "${NUC_USER}@${NUC_HOST}" \
  "sudo docker cp ${CONTAINER}:${LATEST_MP4} /tmp/$(basename "${LATEST_MP4}") && \
   sudo docker cp ${CONTAINER}:${LATEST_JSON} /tmp/$(basename "${LATEST_JSON}")"
scp "${NUC_USER}@${NUC_HOST}:/tmp/$(basename "${LATEST_MP4}")"  "${LOCAL_MP4}"
scp "${NUC_USER}@${NUC_HOST}:/tmp/$(basename "${LATEST_JSON}")" "${LOCAL_JSON}"
# Clean up the temp copies on NUC host
ssh "${NUC_USER}@${NUC_HOST}" \
  "rm -f /tmp/$(basename "${LATEST_MP4}") /tmp/$(basename "${LATEST_JSON}")"

echo "Video metadata:"
cat "${LOCAL_JSON}"

# ---------- 3. Run splat pipeline locally ----------
echo ""
echo "=== [3/3] running splat_pipeline.sh on ${LOCAL_MP4} ==="
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
"${SCRIPT_DIR}/splat_pipeline.sh" "${LOCAL_MP4}" "${RUN_NAME}"

echo ""
echo "============================================================"
echo "  fetch_and_splat.sh complete."
echo "  Captured video:  ${LOCAL_MP4}"
echo "  Metadata:        ${LOCAL_JSON}"
echo "  Splat:           \${SPLAT_BASE_DIR:-/home/robodog/splat_runs}/${RUN_NAME}/export"
echo "============================================================"
